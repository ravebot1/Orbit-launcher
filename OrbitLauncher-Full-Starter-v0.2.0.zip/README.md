# Orbit Launcher — expanded starter (v0.2.0)

This project expands the initial visual concept into a basic Android TV launcher prototype.

## Included in this build
- Home screen with a London dusk background and teal/premium dark styling
- App drawer listing launchable apps installed on the device
- Pin/unpin apps to the main screen and add/remove favourites
- Launch installed apps from Orbit
- Orbit Settings menu with colour schemes (Teal, Blue, Violet, Amber, Rose)
- Clock format options (24h, 12h with AM/PM, large clock, hide clock)
- Weather format options (Celsius/Fahrenheit, compact/detailed, hide weather)
- Live London weather fetched from Open-Meteo when the device has internet
- Wi-Fi/network information panel and shortcut to Android network settings
- Wallpaper choices and direct shortcut to Android Streamer settings
- GitHub Actions workflow to build a debug APK

## Upload using your phone
1. Download and extract this ZIP.
2. In your GitHub repository, upload the **contents** of this folder to the repository root.
3. Ensure `.github/workflows/build-apk.yml` is included.
4. Go to **Actions → Build Orbit Launcher APK → Run workflow**.
5. Download the `Orbit-Launcher-APK` artifact from the completed run, then extract it to get `app-debug.apk`.

## Notes and limitations
- The included wallpaper choices currently share the bundled London image except the midnight option, which changes the hero text. More wallpaper assets and automatic weather/time scene switching are future polish.
- Weather is fetched from Open-Meteo and requires internet. If offline or blocked by device firmware, it displays an unavailable message.
- Wi-Fi SSID/link details may be hidden by Android version, permission restrictions, or Google TV firmware. The panel explains this and provides a shortcut to system network settings.
- Android TV/Google TV firmware may restrict choosing third-party HOME apps. If Orbit does not appear as a home option, use the device's system settings/launcher controls where available.
- This is a prototype starter, not a signed production release. Verify the GitHub Actions build and test on the actual Google TV Streamer before relying on it.
