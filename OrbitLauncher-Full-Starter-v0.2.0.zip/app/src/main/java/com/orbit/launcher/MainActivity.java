package com.orbit.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.wifi.WifiManager;
import android.net.wifi.WifiInfo;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.text.format.Formatter;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(5,14,25);
    private final int TEAL = Color.rgb(0,229,229);
    private final Handler handler = new Handler();
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;
    private LinearLayout root;
    private TextView clockView, weatherView, wifiView, heroTitle, heroSub;
    private Runnable ticker;
    private String weatherSummary = "London weather loading…";
    private String weatherEmoji = "☁";
    private int temperature = 0;
    private long lastWeatherFetch = 0;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        prefs = getSharedPreferences("orbit", MODE_PRIVATE);
        hideSystemUi();
        buildHome();
        fetchWeather();
        startClock();
    }

    @Override public void onResume() {
        super.onResume();
        hideSystemUi();
        if (root != null) buildHome();
    }

    @Override public void onDestroy() {
        super.onDestroy();
        if (ticker != null) handler.removeCallbacks(ticker);
        executor.shutdownNow();
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    private int accent() {
        String s = prefs.getString("scheme", "Teal");
        switch (s) {
            case "Amber": return Color.rgb(255,184,77);
            case "Violet": return Color.rgb(184,130,255);
            case "Blue": return Color.rgb(83,164,255);
            case "Rose": return Color.rgb(255,116,160);
            default: return TEAL;
        }
    }

    private void buildHome() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(34), dp(16), dp(34), dp(14));
        try { root.setBackground(getDrawable(R.drawable.london_dusk)); }
        catch (Exception e) { root.setBackgroundColor(BG); }
        setContentView(root);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = text("Orbit", 26, Color.WHITE, true);
        logo.setLetterSpacing(.02f);
        top.addView(logo, new LinearLayout.LayoutParams(0, -2, 1));
        Button home = smallButton("HOME", () -> buildHome());
        Button drawer = smallButton("APPS", () -> showAppDrawer());
        Button settings = smallButton("ORBIT SETTINGS", () -> showSettings());
        top.addView(home); top.addView(drawer); top.addView(settings);
        LinearLayout status = new LinearLayout(this);
        status.setGravity(Gravity.CENTER_VERTICAL);
        wifiView = text(wifiLabel(), 13, Color.WHITE, false);
        wifiView.setFocusable(true);
        wifiView.setOnClickListener(v -> showWifiPanel());
        status.addView(wifiView);
        weatherView = text("   " + weatherIcon() + " " + weatherText(), 14, Color.WHITE, true);
        weatherView.setFocusable(true);
        weatherView.setOnClickListener(v -> showWeatherDetails());
        status.addView(weatherView);
        clockView = text("   " + clockText(), clockSize(), Color.WHITE, true);
        clockView.setFocusable(true);
        status.addView(clockView);
        top.addView(status);
        root.addView(top, new LinearLayout.LayoutParams(-1, dp(44)));

        TextView greeting = text("GOOD " + (isNight() ? "EVENING" : "DAY"), 13, Color.rgb(225,235,245), true);
        greeting.setLetterSpacing(.16f);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, -2); gp.topMargin = dp(25);
        root.addView(greeting, gp);
        heroTitle = text(heroText(), 30, Color.WHITE, true);
        root.addView(heroTitle);
        heroSub = text("A little London atmosphere. Everything you love, one click away.", 14, Color.rgb(228,237,246), false);
        root.addView(heroSub);

        addSection("YOUR APPS", getPinnedApps(), true);
        addSection("FAVOURITES", getFavourites(), false);

        LinearLayout bottom = new LinearLayout(this);
        bottom.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        Button apps = smallButton("APP DRAWER", () -> showAppDrawer());
        Button wallpaper = smallButton("WALLPAPER", () -> showWallpaperSettings());
        Button streamer = smallButton("STREAMER SETTINGS", () -> openStreamerSettings());
        bottom.addView(apps); bottom.addView(wallpaper); bottom.addView(streamer);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(38)); bp.topMargin = dp(4);
        root.addView(bottom, bp);
        updateClockUi();
    }

    private void addSection(String title, List<AppEntry> items, boolean apps) {
        TextView heading = text(title, 13, Color.rgb(230,240,248), true);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.topMargin = dp(apps ? 16 : 12); hp.bottomMargin = dp(7);
        root.addView(heading, hp);
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        if (items.isEmpty()) {
            TextView empty = text(apps ? "No pinned apps yet — open Apps to add some." : "No favourites selected yet.", 14, Color.LTGRAY, false);
            row.addView(empty, new LinearLayout.LayoutParams(-1, dp(56)));
        }
        int index = 0;
        for (AppEntry app : items) {
            final AppEntry entry = app;
            TextView tile = text(app.label, apps ? 15 : 13, Color.WHITE, true);
            tile.setGravity(Gravity.CENTER);
            tile.setPadding(dp(10), dp(8), dp(10), dp(8));
            GradientDrawable shape = new GradientDrawable();
            shape.setColor(Color.argb(220, 7, 20, 34));
            shape.setCornerRadius(dp(12));
            shape.setStroke(dp(index == 0 ? 2 : 1), index == 0 ? accent() : Color.argb(100, 160,190,210));
            tile.setBackground(shape);
            tile.setFocusable(true);
            tile.setOnFocusChangeListener((v, focused) -> {
                GradientDrawable d = new GradientDrawable();
                d.setColor(Color.argb(focused ? 245 : 220, 7,20,34));
                d.setCornerRadius(dp(12)); d.setStroke(dp(focused ? 3 : 1), focused ? accent() : Color.argb(100,160,190,210));
                v.setBackground(d); v.setScaleX(focused ? 1.05f : 1f); v.setScaleY(focused ? 1.05f : 1f);
            });
            tile.setOnClickListener(v -> launchOrExplain(entry));
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(dp(apps ? 150 : 190), dp(apps ? 66 : 58));
            tp.rightMargin = dp(9); row.addView(tile, tp); index++;
        }
        if (apps) {
            TextView plus = tile("+ Add apps", dp(150), dp(66));
            plus.setOnClickListener(v -> showAppDrawer());
            LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(150), dp(66)); pp.rightMargin = dp(8); row.addView(plus, pp);
        }
        scroll.addView(row);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, dp(apps ? 74 : 66)));
    }

    private TextView tile(String label, int width, int height) {
        TextView t = text(label, 14, Color.WHITE, true); t.setGravity(Gravity.CENTER);
        GradientDrawable d = new GradientDrawable(); d.setColor(Color.argb(220,7,20,34)); d.setCornerRadius(dp(12)); d.setStroke(dp(1), accent());
        t.setBackground(d); t.setFocusable(true); return t;
    }

    private List<AppEntry> getLaunchableApps() {
        List<AppEntry> list = new ArrayList<>();
        PackageManager pm = getPackageManager();
        Intent query = new Intent(Intent.ACTION_MAIN, null); query.addCategory(Intent.CATEGORY_LAUNCHER);
        for (android.content.pm.ResolveInfo ri : pm.queryIntentActivities(query, 0)) {
            String pkg = ri.activityInfo.packageName;
            if (pkg.equals(getPackageName())) continue;
            String label = ri.loadLabel(pm).toString();
            list.add(new AppEntry(label, pkg));
        }
        Collections.sort(list, Comparator.comparing(a -> a.label.toLowerCase(Locale.ROOT)));
        return list;
    }

    private List<AppEntry> getPinnedApps() { return getSavedApps("pinned"); }
    private List<AppEntry> getFavourites() { return getSavedApps("favourites"); }

    private List<AppEntry> getSavedApps(String key) {
        String raw = prefs.getString(key, "");
        List<AppEntry> result = new ArrayList<>();
        if (raw.isEmpty()) return result;
        for (String pkg : raw.split("\\n")) {
            for (AppEntry app : getLaunchableApps()) if (app.pkg.equals(pkg)) { result.add(app); break; }
        }
        return result;
    }

    private void toggleSaved(String key, String pkg) {
        List<String> values = new ArrayList<>();
        String raw = prefs.getString(key, "");
        if (!raw.isEmpty()) Collections.addAll(values, raw.split("\\n"));
        if (values.contains(pkg)) values.remove(pkg); else values.add(pkg);
        prefs.edit().putString(key, join(values)).apply();
    }
    private String join(List<String> values) {
        StringBuilder b = new StringBuilder();
        for (String s : values) { if (b.length() > 0) b.append('\n'); b.append(s); }
        return b.toString();
    }

    private void showAppDrawer() {
        List<AppEntry> apps = getLaunchableApps();
        LinearLayout panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL); panel.setPadding(dp(22),dp(12),dp(22),dp(12));
        panel.setBackgroundColor(Color.rgb(8,18,30));
        TextView title = text("APP DRAWER  ·  Select an app to pin or launch", 21, Color.WHITE, true);
        panel.addView(title);
        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        for (AppEntry app : apps) {
            LinearLayout line = new LinearLayout(this); line.setGravity(Gravity.CENTER_VERTICAL);
            TextView label = text(app.label, 16, Color.WHITE, false);
            line.addView(label, new LinearLayout.LayoutParams(0, dp(48), 1));
            Button pin = smallButton(isSaved("pinned", app.pkg) ? "UNPIN" : "PIN", () -> { toggleSaved("pinned", app.pkg); showAppDrawer(); });
            Button fav = smallButton(isSaved("favourites", app.pkg) ? "★" : "☆", () -> { toggleSaved("favourites", app.pkg); showAppDrawer(); });
            Button launch = smallButton("OPEN", () -> launchOrExplain(app));
            line.addView(pin); line.addView(fav); line.addView(launch); list.addView(line);
            View sep = new View(this); sep.setBackgroundColor(Color.argb(45,255,255,255)); list.addView(sep, new LinearLayout.LayoutParams(-1,dp(1)));
        }
        scroll.addView(list); panel.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        AlertDialog dialog = new AlertDialog.Builder(this).setView(panel).setNegativeButton("CLOSE", (d,w) -> buildHome()).create();
        dialog.getWindow();
        dialog.show();
        dialog.getWindow().setLayout(getResources().getDisplayMetrics().widthPixels * 3 / 4, getResources().getDisplayMetrics().heightPixels * 4 / 5);
    }

    private boolean isSaved(String key, String pkg) {
        String raw = prefs.getString(key, "");
        for (String s : raw.split("\\n")) if (s.equals(pkg)) return true;
        return false;
    }

    private void showSettings() {
        String[] sections = {"Colour scheme", "Weather format & icon", "Clock settings", "Wallpaper settings", "Open Streamer settings", "About Orbit"};
        new AlertDialog.Builder(this).setTitle("Orbit Settings").setItems(sections, (d, which) -> {
            switch(which) {
                case 0: chooseScheme(); break;
                case 1: chooseWeather(); break;
                case 2: chooseClock(); break;
                case 3: showWallpaperSettings(); break;
                case 4: openStreamerSettings(); break;
                default: new AlertDialog.Builder(this).setTitle("Orbit Launcher").setMessage("Concept launcher • version 0.2.0\\nSettings are stored on this device. Some Android TV firmware may restrict replacing the system home app.").setPositiveButton("OK", null).show();
            }
        }).show();
    }

    private void chooseScheme() {
        String[] schemes = {"Teal", "Blue", "Violet", "Amber", "Rose"};
        new AlertDialog.Builder(this).setTitle("Colour scheme").setSingleChoiceItems(schemes, schemeIndex(), (d, which) -> {
            prefs.edit().putString("scheme", schemes[which]).apply(); d.dismiss(); buildHome();
        }).setNegativeButton("CANCEL", null).show();
    }
    private int schemeIndex() {
        String s = prefs.getString("scheme", "Teal");
        String[] a = {"Teal","Blue","Violet","Amber","Rose"};
        for(int i=0;i<a.length;i++) if(a[i].equals(s)) return i; return 0;
    }

    private void chooseWeather() {
        String[] choices = {"Celsius · compact (14° ☂)", "Celsius · detailed (14°C · Rain)", "Fahrenheit · compact", "Fahrenheit · detailed", "Hide weather"};
        new AlertDialog.Builder(this).setTitle("Weather format & icon").setSingleChoiceItems(choices, prefs.getInt("weatherFormat",0), (d,w) -> {
            prefs.edit().putInt("weatherFormat",w).apply(); d.dismiss(); buildHome();
        }).setNegativeButton("CANCEL", null).show();
    }

    private void chooseClock() {
        String[] choices = {"24-hour · standard", "12-hour · AM/PM", "24-hour · large", "12-hour · large", "Hide clock"};
        new AlertDialog.Builder(this).setTitle("Clock settings").setSingleChoiceItems(choices, prefs.getInt("clockFormat",0), (d,w) -> {
            prefs.edit().putInt("clockFormat",w).apply(); d.dismiss(); buildHome();
        }).setNegativeButton("CANCEL", null).show();
    }

    private void showWallpaperSettings() {
        String[] choices = {"London dusk (included)", "Midnight blue", "Rainy glass", "Restore London dusk"};
        new AlertDialog.Builder(this).setTitle("Wallpaper settings").setItems(choices, (d,w) -> {
            prefs.edit().putString("wallpaper", w == 1 ? "midnight" : w == 2 ? "rainy" : "london").apply();
            buildHome();
        }).setNegativeButton("CLOSE", null).show();
    }

    private void openStreamerSettings() {
        try { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
        catch (Exception e) { try { startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)); } catch (Exception ignored) {
            new AlertDialog.Builder(this).setMessage("This device did not expose the system Settings screen to Orbit. Open Settings from the Streamer home screen.").setPositiveButton("OK",null).show();
        }}
    }

    private void showWifiPanel() {
        String name = "Unavailable";
        try {
            WifiManager wm = (WifiManager)getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            WifiInfo info = wm.getConnectionInfo();
            if (info != null && info.getSSID() != null && !info.getSSID().equals("<unknown ssid>")) name = info.getSSID().replace("\"","");
        } catch (Exception ignored) {}
        String state = "Network details are limited by Android TV privacy and firmware rules.";
        try {
            ConnectivityManager cm = (ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
            android.net.Network n = cm.getActiveNetwork();
            NetworkCapabilities caps = cm.getNetworkCapabilities(n);
            if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) state = "Connected via Wi-Fi";
            else if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) state = "Connected via Ethernet";
            else state = "No active network detected";
        } catch (Exception ignored) {}
        final String ssid = name;
        new AlertDialog.Builder(this).setTitle("Wi-Fi & Network").setMessage("Network: " + ssid + "\\n" + state + "\\n\\nAndroid may hide the Wi-Fi name or link speed on some firmware.").setPositiveButton("NETWORK SETTINGS", (d,w) -> {
            try { startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)); } catch(Exception e) { openStreamerSettings(); }
        }).setNegativeButton("CLOSE", null).show();
    }

    private void showWeatherDetails() {
        new AlertDialog.Builder(this).setTitle(weatherIcon() + " London weather").setMessage(weatherText() + "\\n" + weatherSummary + "\\n\\nWeather data: Open-Meteo, refreshed periodically when internet access is available.").setPositiveButton("REFRESH", (d,w) -> { fetchWeather(); }).setNegativeButton("CLOSE", null).show();
    }

    private void fetchWeather() {
        if (System.currentTimeMillis() - lastWeatherFetch < 120000) return;
        lastWeatherFetch = System.currentTimeMillis();
        executor.execute(() -> {
            HttpURLConnection conn = null;
            try {
                URL url = new URL("https://api.open-meteo.com/v1/forecast?latitude=51.5072&longitude=-0.1276&current=temperature_2m,weather_code,is_day&timezone=Europe%2FLondon");
                conn = (HttpURLConnection)url.openConnection(); conn.setConnectTimeout(5000); conn.setReadTimeout(5000);
                java.io.InputStream in = conn.getInputStream();
                java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
                byte[] buffer = new byte[1024]; int n;
                while((n=in.read(buffer))!=-1) out.write(buffer,0,n);
                JSONObject current = new JSONObject(new String(out.toByteArray(), "UTF-8")).getJSONObject("current");
                int code = current.optInt("weather_code", 3);
                int temp = (int)Math.round(current.optDouble("temperature_2m", 14));
                String desc = weatherDescription(code);
                String icon = weatherEmoji(code);
                runOnUiThread(() -> {
                    temperature = temp; weatherSummary = desc; weatherEmoji = icon;
                    if (weatherView != null) weatherView.setText("   " + weatherIcon() + " " + weatherText());
                    if (heroTitle != null) heroTitle.setText(heroText());
                    if (heroSub != null) heroSub.setText(desc + " in London · A little London atmosphere, everything you love in one place.");
                });
            } catch(Exception e) {
                runOnUiThread(() -> { weatherSummary = "Weather unavailable — check internet connection"; if (weatherView != null) weatherView.setText("   ☁ London weather unavailable"); });
            } finally { if(conn != null) conn.disconnect(); }
        });
    }

    private String weatherDescription(int c) {
        if (c==0) return "Clear skies";
        if (c==1 || c==2) return "Mostly clear / partly cloudy";
        if (c==3) return "Cloudy";
        if (c==45 || c==48) return "Foggy";
        if (c>=51 && c<=67) return "Drizzle or rain";
        if (c>=71 && c<=77) return "Snow";
        if (c>=80 && c<=82) return "Rain showers";
        if (c>=85 && c<=86) return "Snow showers";
        if (c>=95) return "Thunderstorms";
        return "London weather";
    }
    private String weatherEmoji(int c) {
        if(c==0) return isNight() ? "☾" : "☀";
        if(c==1 || c==2) return "⛅";
        if(c==45 || c==48) return "🌫";
        if((c>=51 && c<=67) || (c>=80 && c<=82)) return "☂";
        if(c>=71 && c<=86) return "❄";
        if(c>=95) return "⛈";
        return "☁";
    }
    private String weatherIcon() {
        int fmt = prefs.getInt("weatherFormat",0);
        if(fmt == 4) return "";
        if(fmt == 0 || fmt == 1) return weatherEmoji;
        return weatherEmoji;
    }
    private String weatherText() {
        int fmt = prefs.getInt("weatherFormat",0);
        if(fmt == 4) return "";
        int t = temperature;
        if(fmt == 2 || fmt == 3) t = (int)Math.round(temperature * 9.0/5.0 + 32);
        String unit = (fmt == 2 || fmt == 3) ? "°F" : "°C";
        if(fmt == 1 || fmt == 3) return t + unit + " · " + weatherSummary;
        return t + "°";
    }

    private String heroText() {
        if (prefs.getString("wallpaper","london").equals("midnight")) return "London after dark";
        if (weatherSummary.toLowerCase(Locale.ROOT).contains("rain") || weatherSummary.toLowerCase(Locale.ROOT).contains("drizzle")) return "London, It’s Raining";
        return "London, " + weatherSummary;
    }
    private boolean isNight() {
        java.util.Calendar c = java.util.Calendar.getInstance();
        int h = c.get(java.util.Calendar.HOUR_OF_DAY); return h < 6 || h >= 19;
    }
    private String clockText() {
        int fmt = prefs.getInt("clockFormat",0);
        if(fmt == 4) return "";
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat((fmt == 1 || fmt == 3) ? "h:mm a" : "HH:mm", Locale.UK);
        return sdf.format(new java.util.Date());
    }
    private int clockSize() { int f = prefs.getInt("clockFormat",0); return (f==2 || f==3) ? 22 : 17; }
    private void startClock() {
        ticker = new Runnable() { @Override public void run() {
            if(clockView != null) { clockView.setText("   " + clockText()); clockView.setTextSize(clockSize()); clockView.setVisibility(prefs.getInt("clockFormat",0)==4 ? View.GONE : View.VISIBLE); }
            if(weatherView != null) weatherView.setVisibility(prefs.getInt("weatherFormat",0)==4 ? View.GONE : View.VISIBLE);
            handler.postDelayed(this, 15000);
        }};
        handler.post(ticker);
    }
    private void updateClockUi() {
        if(clockView != null) { clockView.setText("   " + clockText()); clockView.setTextSize(clockSize()); clockView.setVisibility(prefs.getInt("clockFormat",0)==4 ? View.GONE : View.VISIBLE); }
        if(weatherView != null) weatherView.setVisibility(prefs.getInt("weatherFormat",0)==4 ? View.GONE : View.VISIBLE);
    }
    private String wifiLabel() { return "◉ Wi-Fi"; }

    private void launchOrExplain(AppEntry app) {
        try {
            Intent launch = getPackageManager().getLaunchIntentForPackage(app.pkg);
            if (launch != null) { launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(launch); }
            else Toast.makeText(this, "No launch activity found for " + app.label, Toast.LENGTH_SHORT).show();
        } catch(Exception e) { Toast.makeText(this, "Could not open " + app.label, Toast.LENGTH_SHORT).show(); }
    }

    private Button smallButton(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setTextSize(10); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setPadding(dp(7),0,dp(7),0); b.setMinWidth(0); b.setMinimumWidth(0);
        GradientDrawable d = new GradientDrawable(); d.setColor(Color.argb(190,7,20,34)); d.setCornerRadius(dp(8)); d.setStroke(dp(1), Color.argb(110, Color.red(accent()), Color.green(accent()), Color.blue(accent())));
        b.setBackground(d); b.setFocusable(true); b.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, dp(34)); p.leftMargin = dp(4); b.setLayoutParams(p);
        return b;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL)); t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density); }

    private static class AppEntry {
        final String label, pkg;
        AppEntry(String l, String p) { label=l; pkg=p; }
    }
}
