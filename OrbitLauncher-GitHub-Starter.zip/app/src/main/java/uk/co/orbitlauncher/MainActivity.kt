package uk.co.orbitlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("orbit", Context.MODE_PRIVATE) }
    private val worker = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var root: LinearLayout
    private lateinit var header: LinearLayout
    private lateinit var clock: TextView
    private lateinit var weather: TextView
    private lateinit var wifiButton: TextView
    private var weatherSummary = "London weather loading…"
    private var weatherCode = -1
    private var tempC = 0
    private val recent = LinkedHashSet<String>()
    private val accents = listOf(
        Triple("Aurora", Color.rgb(89, 226, 190), Color.rgb(23, 48, 55)),
        Triple("Nebula", Color.rgb(171, 133, 255), Color.rgb(45, 32, 67)),
        Triple("Solar", Color.rgb(255, 174, 92), Color.rgb(65, 42, 29)),
        Triple("Glacier", Color.rgb(107, 190, 255), Color.rgb(25, 45, 69)),
        Triple("Rose", Color.rgb(255, 125, 164), Color.rgb(65, 31, 48))
    )
    private val accent get() = accents[prefs.getInt("accent", 0).coerceIn(accents.indices)]
    private val bg get() = Color.rgb(9, 14, 23)
    private val card get() = Color.rgb(21, 30, 44)

    private val clockTick = object : Runnable {
        override fun run() {
            if (::clock.isInitialized) clock.text = SimpleDateFormat("EEE, d MMM  •  HH:mm", Locale.UK).format(Date())
            handler.postDelayed(this, 30_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        render()
        fetchWeather()
        handler.post(clockTick)
    }
    override fun onDestroy() { handler.removeCallbacks(clockTick); worker.shutdownNow(); super.onDestroy() }
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun text(s: String, size: Float, color: Int = Color.WHITE) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); gravity = Gravity.CENTER_VERTICAL
    }
    private fun rounded(color: Int, radius: Int = 16) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun render() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(30), dp(18), dp(30), dp(20)); setBackgroundColor(bg) }
        header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(text("◉  ORBIT", 26f, accent.first).apply { typeface = Typeface.DEFAULT_BOLD })
        header.addView(Space(this), LinearLayout.LayoutParams(0, 1, 1f))
        wifiButton = text("◉ Wi-Fi", 15f).apply { setPadding(dp(12), dp(8), dp(12), dp(8)); background = rounded(card); isFocusable = true; setOnClickListener { showWifiDetails() } }
        header.addView(wifiButton)
        weather = text("  ☁  London · …", 15f).apply { setPadding(dp(12), dp(8), dp(12), dp(8)); isFocusable = true; background = rounded(card); setOnClickListener { showWeatherDetails() } }
        header.addView(weather)
        clock = text("", 17f, Color.LTGRAY).apply { setPadding(dp(14), 0, 0, 0) }
        header.addView(clock)
        root.addView(header, LinearLayout.LayoutParams(-1, dp(54)))
        root.addView(text("YOUR SPACE", 13f, accent.first).apply { setPadding(0, dp(10), 0, dp(6)) })
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(14), dp(20), dp(14))
            background = rounded(accent.second, 20)
        }
        val timeOfDay = when (java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)) { in 6..10 -> "MORNING"; in 11..16 -> "DAYTIME"; in 17..20 -> "EVENING"; else -> "NIGHT" }
        hero.addView(text("LONDON  /  $timeOfDay", 12f, accent.first))
        hero.addView(text(weatherSummary, 24f).apply { typeface = Typeface.DEFAULT_BOLD })
        hero.addView(text("Atmospheric city backdrop adapts to the weather and time of day.", 13f, Color.LTGRAY))
        root.addView(hero, LinearLayout.LayoutParams(-1, dp(104)).apply { bottomMargin = dp(12) })
        root.addView(text("YOUR APPS  ·  Long-press to favourite", 13f, accent.first).apply { setPadding(0, dp(4), 0, dp(5)) })
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        populateApps(list)
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val footer = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val settings = text("⚙  Launcher settings", 15f, accent.first).apply { isFocusable = true; setPadding(dp(12), dp(10), dp(18), dp(10)); background = rounded(card); setOnClickListener { showLauncherSettings() } }
        val device = text("▣  Streamer settings", 15f).apply { isFocusable = true; setPadding(dp(12), dp(10), dp(12), dp(10)); background = rounded(card); setOnClickListener { openDeviceSettings() } }
        footer.addView(settings); footer.addView(Space(this), LinearLayout.LayoutParams(dp(12), 1)); footer.addView(device)
        root.addView(footer, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) })
        setContentView(root)
    }

    private fun populateApps(container: LinearLayout) {
        container.removeAllViews()
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0).filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }.sortedWith(compareByDescending<android.content.pm.ResolveInfo> { prefs.getStringSet("favourites", emptySet())!!.contains(it.activityInfo.packageName) }.thenBy { it.loadLabel(pm).toString().lowercase(Locale.UK) })
        val rows = apps.chunked(5)
        rows.forEach { row ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.forEach { info ->
                val pkg = info.activityInfo.packageName
                val title = info.loadLabel(pm).toString()
                val tile = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(6), dp(8), dp(6), dp(8))
                    background = rounded(card); isFocusable = true; isFocusableInTouchMode = true
                    val icon = ImageView(this@MainActivity).apply { setImageDrawable(info.loadIcon(pm)) }
                    addView(icon, LinearLayout.LayoutParams(dp(44), dp(44)))
                    addView(text(title, 12f).apply { gravity = Gravity.CENTER; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
                    if (prefs.getStringSet("favourites", emptySet())!!.contains(pkg)) addView(text("★ FAVOURITE", 9f, accent.first).apply { gravity = Gravity.CENTER })
                    setOnClickListener { launch(pkg) }
                    setOnLongClickListener { toggleFavourite(pkg); render(); true }
                    setOnFocusChangeListener { v, focus -> v.background = rounded(if (focus) accent.second else card); v.scaleX = if (focus) 1.04f else 1f; v.scaleY = if (focus) 1.04f else 1f }
                }
                line.addView(tile, LinearLayout.LayoutParams(0, dp(100), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
            }
            repeat(5-row.size) { line.addView(Space(this), LinearLayout.LayoutParams(0, dp(100), 1f)) }
            container.addView(line)
        }
        if (apps.isEmpty()) container.addView(text("No TV apps found.", 18f))
    }

    private fun launch(pkg: String) {
        val launch = packageManager.getLeanbackLaunchIntentForPackage(pkg) ?: packageManager.getLaunchIntentForPackage(pkg)
        if (launch != null) {
            recent.remove(pkg); recent.add(pkg); while (recent.size > 6) recent.remove(recent.first())
            try { startActivity(launch) } catch (_: Exception) { Toast.makeText(this, "Could not launch app", Toast.LENGTH_SHORT).show() }
        }
    }
    private fun toggleFavourite(pkg: String) {
        val set = prefs.getStringSet("favourites", emptySet())!!.toMutableSet()
        if (!set.add(pkg)) set.remove(pkg)
        prefs.edit().putStringSet("favourites", set).apply()
        Toast.makeText(this, if (set.contains(pkg)) "Added to favourites" else "Removed favourite", Toast.LENGTH_SHORT).show()
    }

    private fun showWifiDetails() {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork
        val caps = if (network != null) cm.getNetworkCapabilities(network) else null
        val connected = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        var ssid = "Unavailable (Android may hide SSID)"
        try {
            val info = (applicationContext.getSystemService(WIFI_SERVICE) as WifiManager).connectionInfo
            if (info.ssid != null && info.ssid != "<unknown ssid>") ssid = info.ssid.trim('"')
        } catch (_: Exception) {}
        val speed = caps?.linkDownstreamBandwidthKbps?.let { if (it >= 1000) "${it/1000} Mbps estimated link bandwidth" else "$it kbps estimated link bandwidth" } ?: "Speed unavailable"
        AlertDialog.Builder(this).setTitle("Wi-Fi details")
            .setMessage("Network: ${if (connected) "Wi-Fi connected" else "Not connected over Wi-Fi"}\\nName: $ssid\\n$speed\\n\\nAndroid reports link bandwidth, not a live internet speed test.")
            .setPositiveButton("OK", null).setNeutralButton("Network settings") { _, _ -> openNetworkSettings() }.show()
    }
    private fun showWeatherDetails() {
        AlertDialog.Builder(this).setTitle("London weather").setMessage("$weatherSummary\\n${if (weatherCode >= 0) "Weather code: $weatherCode" else "Weather unavailable"}\\n\\nThe current starter uses Open-Meteo and does not require an API key.")
            .setPositiveButton("OK", null).show()
    }
    private fun fetchWeather() {
        worker.execute {
            try {
                val conn = URL("https://api.open-meteo.com/v1/forecast?latitude=51.5072&longitude=-0.1276&current=temperature_2m,weather_code,is_day&timezone=Europe%2FLondon").openConnection() as HttpURLConnection
                conn.connectTimeout = 5000; conn.readTimeout = 5000
                val data = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val current = JSONObject(data).getJSONObject("current")
                tempC = current.getDouble("temperature_2m").toInt()
                weatherCode = current.getInt("weather_code")
                val isDay = current.optInt("is_day", 1) == 1
                val desc = when (weatherCode) {
                    0 -> "Clear skies"; 1 -> "Mostly clear"; 2 -> "Partly cloudy"; 3 -> "Overcast"
                    45, 48 -> "Foggy London"; 51, 53, 55 -> "Drizzly London"; 56, 57 -> "Freezing drizzle"
                    61, 63, 65 -> "Rainy London"; 66, 67 -> "Freezing rain"; 71, 73, 75, 77 -> "Snowy London"
                    80, 81, 82 -> "Showers over London"; 85, 86 -> "Snow showers"; 95, 96, 99 -> "Stormy London"; else -> "London weather"
                }
                weatherSummary = "$desc  ·  $tempC°C  ·  ${if (isDay) "Day" else "Night"}"
                runOnUiThread {
                    if (::weather.isInitialized) weather.text = "  ${if (weatherCode in listOf(61,63,65,80,81,82)) "☂" else if (weatherCode in listOf(0,1)) "☀" else "☁"}  London · ${tempC}°"
                    if (::root.isInitialized) {
                        // Refresh hero while retaining launcher screen and preferences.
                        render()
                    }
                }
            } catch (_: Exception) {
                weatherSummary = "London weather unavailable"
                runOnUiThread { if (::root.isInitialized) render() }
            }
        }
    }

    private fun showLauncherSettings() {
        val choices = arrayOf("Choose colour theme", "Choose wallpaper atmosphere", "Refresh weather", "Refresh app list")
        AlertDialog.Builder(this).setTitle("Orbit launcher settings").setItems(choices) { _, which ->
            when (which) {
                0 -> chooseTheme()
                1 -> chooseWallpaper()
                2 -> fetchWeather()
                3 -> render()
            }
        }.show()
    }
    private fun chooseTheme() {
        val names = accents.map { it.first }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Colour combination").setSingleChoiceItems(names, prefs.getInt("accent", 0)) { dialog, which ->
            prefs.edit().putInt("accent", which).apply(); dialog.dismiss(); render()
        }.setNegativeButton("Cancel", null).show()
    }
    private fun chooseWallpaper() {
        val choices = arrayOf("London weather + day/night (default)", "Space", "Nature", "Ocean", "Minimal gradient")
        AlertDialog.Builder(this).setTitle("Wallpaper atmosphere").setSingleChoiceItems(choices, prefs.getInt("wallpaper", 0)) { dialog, which ->
            prefs.edit().putInt("wallpaper", which).apply()
            Toast.makeText(this, "Selected ${choices[which]}. Wallpaper art packs are a follow-up task; this starter changes the saved selection only.", Toast.LENGTH_LONG).show()
            dialog.dismiss()
        }.setNegativeButton("Cancel", null).show()
    }
    private fun openDeviceSettings() {
        try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) { Toast.makeText(this, "Open Streamer Settings from the device menu.", Toast.LENGTH_LONG).show() }
    }
    private fun openNetworkSettings() {
        try { startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) } catch (_: Exception) { openDeviceSettings() }
    }
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU || keyCode == KeyEvent.KEYCODE_SETTINGS) { showLauncherSettings(); return true }
        return super.onKeyDown(keyCode, event)
    }
}
