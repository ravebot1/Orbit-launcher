plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "uk.co.orbitlauncher"
    compileSdk = 35
    defaultConfig {
        applicationId = "uk.co.orbitlauncher"
        minSdk = 26
        targetSdk = 28
        versionCode = 2
        versionName = "0.2.0"
    }
}
