# Orbit Launcher — GitHub starter

Custom Android TV launcher for Google TV Streamer. This repo is designed to be maintained through GitHub and rebuilt as an APK when updates are published.

## Features in this starter
- Remote-first TV app grid; OK launches an app.
- Long-press an app to favourite/unfavourite it; favourites persist locally and sort to the front.
- Clock in the top-right.
- Wi-Fi popover showing connection status, SSID when Android exposes it, and Android's reported downstream link bandwidth.
- London weather from Open-Meteo (no API key) with weather/time-of-day text.
- Launcher settings and a shortcut to Android/Streamer settings.
- Five saved accent palettes.
- Wallpaper atmosphere choices saved in settings.

## Honest limitations
This is an early starter, not a fully polished release. The weather panel changes its text based on current London conditions and day/night, but the actual cinematic London background images and selectable Space/Nature/Ocean wallpaper artwork are **not implemented yet**; those are represented as settings choices only. Recent apps are tracked in memory but not yet displayed as a dedicated row. Wi-Fi SSID visibility depends on Android/Google TV permissions and firmware. The bandwidth shown is Android's reported link estimate, not a live internet speed test. Build and test on your own device before choosing it as the Home launcher.

## Build locally
1. Install Android Studio and Android SDK Platform Tools.
2. Clone this repository or download its ZIP.
3. Open the repository root in Android Studio and allow Gradle sync.
4. Build → Build APK(s).
5. APK path: `app/build/outputs/apk/debug/app-debug.apk`.

## Install / update with ADB
Enable Developer options and debugging on the Streamer, connect from the computer, then:

```bash
adb connect DEVICE_IP:PORT
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

For Android Wireless Debugging, pair first using the pairing address/port shown on the TV, then connect using its separate connect address/port. Approve the prompt on the TV.

The `-r` flag updates the existing app while preserving its data as long as the package name and signing key remain the same. For your own updates, keep the same `applicationId` (`uk.co.orbitlauncher`) and use the same signing key. A debug APK built on another machine may have a different debug signing key; Android will reject it as an update if signatures differ. Uninstalling first can remove local settings, so avoid that if you want to preserve preferences.

## GitHub update workflow
- Commit source changes to the repository.
- Build a new APK with a higher `versionCode`.
- For reliable in-place updates, sign every release with the same release key.
- Attach the APK to a GitHub Release. Download it on a computer and install with `adb install -r`, or implement an in-launcher updater later. Android does not allow silent self-updates for ordinary apps; user confirmation is required.
- Do not commit signing keys or passwords to GitHub.

## Set as Home
The app declares both Leanback launcher and Home intents. Install and launch it first. Whether Google TV Streamer offers it as a Home app depends on firmware; some Google TV builds keep control of the Home button. Do not disable the stock launcher. If Orbit does not appear as a Home choice, open it from Apps.

## GitHub repository suggestions
Repository name: `orbit-launcher-android-tv`
Branch: `main`
Tag releases as `v0.2.0`, `v0.3.0`, etc.
