package com.example.orbitlauncher

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    
    // Replace with your GitHub Username and Repository Name
    private val githubUser = "YOUR_GITHUB_USERNAME"
    private val githubRepo = "orbit-launcher"
    private val currentVersion = "v1.0.0"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var updateAvailable by remember { mutableStateOf(false) }
            var latestDownloadUrl by remember { mutableStateOf("") }
            var latestTag by remember { mutableStateOf("") }

            // Check GitHub API for latest release on launch
            LaunchedEffect(Unit) {
                withContext(Dispatchers.IO) {
                    try {
                        val url = URL("https://api.github.com/repos/$githubUser/$githubRepo/releases/latest")
                        val conn = url.openConnection() as HttpURLConnection
                        conn.requestMethod = "GET"
                        conn.setRequestProperty("Accept", "application/vnd.github.v3+json")

                        if (conn.responseCode == 200) {
                            val response = conn.inputStream.bufferedReader().use { it.readText() }
                            val json = JSONObject(response)
                            val tagName = json.getString("tag_name")

                            if (tagName != currentVersion) {
                                val assets = json.getJSONArray("assets")
                                if (assets.length() > 0) {
                                    val downloadUrl = assets.getJSONObject(0).getString("browser_download_url")
                                    withContext(Dispatchers.Main) {
                                        latestTag = tagName
                                        latestDownloadUrl = downloadUrl
                                        updateAvailable = true
                                    }
                                }
                            }
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }

            Surface(modifier = Modifier.fillMaxSize(), color = Color.Black) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color.DarkGray, Color.Black)
                                )
                            )
                    )

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(48.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                var currentTime by remember { mutableStateOf("19:26") }
                                LaunchedEffect(Unit) {
                                    while (true) {
                                        currentTime = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                                        delay(1000)
                                    }
                                }
                                Text(text = currentTime, fontSize = 64.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                Text(text = "Monday, 2 November", fontSize = 18.sp, color = Color.LightGray)
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(Color.Black.copy(alpha = 0.4f))
                                    .padding(16.dp)
                            ) {
                                Text(text = "London • 11°C Mostly Clear", color = Color.White, fontSize = 16.sp)
                            }
                        }

                        // Update Notification Banner (Displays if GitHub has a newer release)
                        if (updateAvailable) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E88E5)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .padding(16.dp)
                                        .fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "New Update Available ($latestTag)",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp
                                    )
                                    Button(
                                        onClick = {
                                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(latestDownloadUrl))
                                            startActivity(intent)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color.White)
                                    ) {
                                        Text(text = "Download APK", color = Color(0xFF1E88E5), fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.align(Alignment.CenterHorizontally),
                            horizontalArrangement = Arrangement.spacedBy(24.dp)
                        ) {
                            AppDockButton(label = "SmartTube") {
                                launchApp("com.liskovsoft.smarttubetv.beta")
                            }
                            AppDockButton(label = "Stremio") {
                                launchApp("com.stremio.one")
                            }
                            AppDockButton(label = "Deezer") {
                                launchApp("deezer.android.app")
                            }
                            AppDockButton(label = "All Apps") {
                                val intent = Intent(Intent.ACTION_MAIN).apply {
                                    addCategory(Intent.CATEGORY_APP_GALLERY)
                                }
                                runCatching { startActivity(intent) }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun launchApp(packageName: String) {
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) {
            startActivity(intent)
        }
    }
}

@Composable
fun AppDockButton(label: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.size(100.dp, 80.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.2f))
    ) {
        Text(text = label, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}
